import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { BindingmaterialPage } from './bindingmaterial';

@NgModule({
  declarations: [
    BindingmaterialPage,
  ],
  imports: [
    IonicPageModule.forChild(BindingmaterialPage),
  ],
})
export class BindingmaterialPageModule {}
