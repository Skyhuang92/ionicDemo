import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { BpalletoutPage } from './bpalletout';

@NgModule({
  declarations: [
    BpalletoutPage,
  ],
  imports: [
    IonicPageModule.forChild(BpalletoutPage),
  ],
})
export class BpalletoutPageModule {}
