import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { StockreturnPage } from './stockreturn';

@NgModule({
  declarations: [
    StockreturnPage,
  ],
  imports: [
    IonicPageModule.forChild(StockreturnPage),
  ],
})
export class StockreturnPageModule {}
