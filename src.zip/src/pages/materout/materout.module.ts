import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { MaterOutPage } from './materout';

@NgModule({
  declarations: [
    MaterOutPage,
  ],
  imports: [
    IonicPageModule.forChild(MaterOutPage),
  ],
})
export class MateroutPageModule {}
