import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { PalletqueryPage } from './palletquery';

@NgModule({
  declarations: [
    PalletqueryPage,
  ],
  imports: [
    IonicPageModule.forChild(PalletqueryPage),
  ],
})
export class PalletqueryPageModule {}
