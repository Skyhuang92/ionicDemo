export const APP_DOWNLOAD = 'http://192.168.31.132:8013/api/download/GetApkFile';//app下载地址
export const APK_DOWNLOAD = 'http://192.168.31.132:8013/api/download/GetApkFile';//apk下载完整地址

